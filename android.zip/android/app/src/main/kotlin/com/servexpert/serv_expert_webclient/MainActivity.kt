package com.servexpert.serv_expert_webclient

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
